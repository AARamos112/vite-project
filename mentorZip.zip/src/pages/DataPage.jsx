

function DataPage() {

    return (
      <>
      <main className='h-screen w-full bg-gray-600 dark:bg-gray-900 '>
        <div className='relative flex items-center justify-center h-screen text-8xl text-white'>
          <h8>Data page</h8>
  
        </div>
      </main>
    </>
    )
  }
  
  export default DataPage